﻿# Slider Show Library
### A JavaScript Librarie To Create Sliedr <br>
[_This is sample for test you_ →](https://matintohidi.github.io/slider-show/slidershow)
Advantages: <br>
- You can create a Slider Show so easy
# How to use
### Install
First you need to download the file and link the script.js file in the src folder to your html document <br>
```html
<script src="script.js"></script>
```
### Use
Then we create a new object for slider <br>
> This is an example for you to understand more 👇
```js
new slider({
    el : document.querySelector('#sliders'),
    slideClass : 'slider',
    currentSlider : (slider) => {},
    auto : 3000
})
```
> In the example above, we select the sliders with id and set the auto time 3000 it means 3 second for fade to next slide  <br>

## Example
For example, we want to fade to the next slide in 3.5 Second ( ***auto : 3500*** ) is executed :
```js
new slider({
    el : document.querySelector('#sliders'),
    slideClass : 'slider',
    currentSlider : (slider) => {},
    auto : 3500
})
```

<br>

## Make sure
you select all the slide elements correctly ( ***el : document.querySelector('#your parent slider name')*** )
```js
new slider({
    el : document.querySelector('#sliders'),
    slideClass : 'slider',
    currentSlider : (slider) => {},
    auto : 3500
})
```

### I hope it was useful for you
