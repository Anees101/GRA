new slider({
    el : document.querySelector('#sliders'),
    slideClass : 'slider',
    currentSlider : (slider) => {},
    auto : 3000
})